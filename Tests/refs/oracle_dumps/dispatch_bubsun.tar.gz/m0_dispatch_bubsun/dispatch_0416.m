<|"ctx" -> <|"AMatExpanded" -> {{0}}, "AMatFactored" -> {{0}}, 
   "SystemSize" -> 1, "ExpansionOrder" -> 50, "WorkingPrecision" -> 200, 
   "ChopPrecision" -> 150, "LinearSolveChopPrecision" -> 150, 
   "HomogeneousSolve" -> "DontExpand", "InvWronskSolver" -> "Auto", 
   "CrosscheckFlags" -> {"WronskInv", "SingularityCheck"}, 
   "CrossCheckPrintOrder" -> 5, "CrossCheckVerifyOrder" -> 5, 
   "IntegrationStrategy" -> "Default", "UseRationalRecurrence" -> True, 
   "Label" -> {2}|>, "bVec" -> {SeriesData[x, 0, {}, 50, 50, 1]}, 
 "epsord" -> 0|>
